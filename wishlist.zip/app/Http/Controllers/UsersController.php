<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\Http\Controllers\Controller; 
use App\User; 
use App\Http\Controllers\CustomheaderController;
use Illuminate\Support\Facades\Auth; 
use App\Utilities\ProxyRequest;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    public function __construct(ProxyRequest $proxy)
    {
        $this->proxy = $proxy;
    }

    public function login()
    {
     $user = User::where('email', request('email'))->first();

    abort_unless($user, 404, 'This combination does not exists.');
    abort_unless(
        \Hash::check(request('password'), $user->password),
        403,
        'This combination does not exists.'
    );

    $resp = $success['token'] = $user->createToken('appToken')->accessToken;
  

      DB::table('users')
                ->where('email',request('email'))
                ->update(['api_token' => $resp]);


    return response([
        'token' => $resp,
        'expiresIn' => 20000,
        'user'=>$user,
        'message' => 'You have been logged in',
    ], 200);
 
    }
     /**
     * Register api.
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
      $validator = Validator::make($request->all(), [
            'fname' => 'required',
            'lname' => 'required',
            'phone' => 'required|regex:/[0-9]{10}/',
            'email' => 'required|email|unique:users',
            'password' => 'required',
        ]);
        if ($validator->fails()) {
          return response()->json([
            'success' => false,
            'message' => $validator->errors(),
          ], 401);
        }
       
        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);
        $success['token'] = $user->createToken('appToken')->accessToken;

        DB::table('users')
                ->where('id', $user['id'])
                ->update(['api_token' => $success['token']]);
          return response()->json([
          'success' => true,
          'token' => $success,
          'user' => $user
      ]);

    }
   
    public function refreshToken()
    {
    $resp = $this->proxy->refreshAccessToken();

    return response([
        'token' => $resp->access_token,
        'expiresIn' => $resp->expires_in,
        'message' => 'Token has been refreshed.',
    ], 200);
}
public function userDetails(){
  $token =  \App\Helpers\AppAuthHelper::instance()->getAuthorizationHeader();
      $user = \App\Helpers\AppAuthHelper::instance()->CheckAuthValidate($token);
    
     
        return response([
        'Status'=>200,
        'message' => 'User Detail Given.',
        'data'=>$user
          ], 200);

      // }else
      // {
      //   echo "user nthi";
      //   return response([
      //   'Status'=>401,
      //   'message' => 'User not authenticated.',
      //   'data'=>''
      //     ], 401);
      // }

}
public function updateprofile(Request $request)
{

  $token =  \App\Helpers\AppAuthHelper::instance()->getAuthorizationHeader();
      $user = \App\Helpers\AppAuthHelper::instance()->CheckAuthValidate($token);

      // print_r($user);
      // die;
      //   if(isset($user['id']))
      // {
      //     $validator = Validator::make($request->all(), [
      //       'fname' => 'required',
      //       'lname' => 'required',
      //       'phone' => 'required'
           
      //   ]);
      //   if ($validator->fails()) {
      //     return response()->json([
      //       'success' => false,
      //       'message' => $validator->errors(),
      //     ], 401);
      //   }
      // var_dump($request->phone);
    
          $rs = DB::table('users')
            ->where('id', (int)$user['id'])
            ->update(['fname' => (string)$request->fname,
                  'lname'=>(string)$request->lname,
                  'phone'=>(string)$request->phone
                ]);
            // echo $rs;
            // die;
      return response([
        'Status'=>'True',
        'message' => 'Data Updated',
        'data'=>''

    ], 200);

    //   }
    //   else
    //   {
    //       return response([
    //     'Status'=>'false',
    //     'message' => 'Something Went Wrong.Profile Not Updated',
    // ], 401);
    //   }

}
public function logout(Request $res)
    {
      $token =  \App\Helpers\AppAuthHelper::instance()->getAuthorizationHeader();
      $user = \App\Helpers\AppAuthHelper::instance()->CheckAuthValidate($token);
      if($user)
      {
         DB::table('users')
                ->where('id', $user['id'])
                ->update(['api_token' => '']);

      return response([
        'Status'=>200,
        'message' => 'Logout Sucessfully.',
    ], 200);
    }
    else
    {
        return response([
        'Status'=>401,
        'message' => 'Something Went Wrong.Not Authorized User',
    ], 401);
    }
  }
}
