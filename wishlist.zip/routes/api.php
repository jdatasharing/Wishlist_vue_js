<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::group(['prefix' => 'v1'], function () {
    Route::post('/login', 'UsersController@login');
    Route::post('/register', 'UsersController@register');

    Route::any('/logout', 'UsersController@logout');
    
    Route::any('/products', 'ApiController@allProducts');
Route::any('/productsdemo', 'ApiController@allProductDemo');
  Route::any('/userDetails','UsersController@userDetails')
  ;
   Route::any('/updateprofile','UsersController@updateprofile');
    Route::any('/demo','UsersController@demo');

    Route::any('/addProductWishlist', 'ApiController@addProductWishlist');

    Route::any('/DeleteProductWishlist', 'ApiController@DeleteProductWishlist');

        Route::any('/demo1','UsersController@demo1');



});
